export OS_AUTH_URL=http://10.10.10.9:5000/v3
export OS_PROJECT_NAME="admin"
export OS_USER_DOMAIN_NAME="admin_domain"
export OS_PROJECT_DOMAIN_NAME="admin_domain"
export OS_USERNAME="admin"
export OS_PASSWORD="ahseiweeNgaik8uX"
export OS_REGION_NAME="RegionOne"
export OS_IDENTITY_API_VERSION=3
